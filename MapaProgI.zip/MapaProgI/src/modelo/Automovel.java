/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author debora.campelo
 */
public class Automovel {
    
    public int motor = 0;
    public int rodas;
    public int portas;
    public int velocidade;
    public double combustivel = 5;
    public double oleo = 0.0;
    public double pneu = 0.0;

    public Automovel() {
    }

    public Automovel(int motor, int rodas, int portas, int velocidade, double combustivel, double oleo, double pneu) {
        this.motor = motor;
        this.rodas = rodas;
        this.portas = portas;
        this.velocidade = velocidade;
        this.combustivel = combustivel;
        this.oleo = oleo;
        this.pneu = pneu;
    }

    public int getMotor() {
        return motor;
    }

    public void setMotor(int motor) {
        this.motor = motor;
    }

    public int getRodas() {
        return rodas;
    }

    public void setRodas(int rodas) {
        this.rodas = rodas;
    }

    public int getPortas() {
        return portas;
    }

    public void setPortas(int portas) {
        this.portas = portas;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    public double getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(double combustivel) {
        this.combustivel = combustivel;
    }

    public double getOleo() {
        return oleo;
    }

    public void setOleo(double oleo) {
        this.oleo = oleo;
    }

    public double getPneu() {
        return pneu;
    }

    public void setPneu(double pneu) {
        this.pneu = pneu;
    }
}
