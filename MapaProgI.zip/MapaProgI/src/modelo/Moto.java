/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author debora.campelo
 */
public class Moto extends Automovel {

    public Moto() {
    }

    public Moto(int motor, int rodas, int portas, int velocidade, double combustivel, double oleo, double pneu) {
        super(motor, rodas, portas, velocidade, combustivel, oleo, pneu);
    }
}
